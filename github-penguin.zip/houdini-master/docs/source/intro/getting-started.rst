Getting started with Houdini
============================

Houdini can be installed like any other Python program:

.. code-block:: bash

    git clone https://github.com/solero/houdini-asyncio
    cd houdini-asyncio
    pip install -r requirements.txt
    python bootstrap.py login

This page is a WIP!