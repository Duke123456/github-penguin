Welcome to Houdini's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro/getting-started
   intro/current-progress

   plugins/introduction



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
